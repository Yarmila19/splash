<?php $__env->startSection('content'); ?>

<h1><?php echo e($post->title); ?></h1>
<p>
	<?php echo e($post->body); ?>

</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/post.blade.php ENDPATH**/ ?>